SACHi-MD V8 FINAL WEB ADMIN

Use this as the GitHub Pages index.html for the admin panel.

1. Replace the old GitHub Pages index.html with this index.html.
2. Open the GitHub Pages site.
3. Paste the CURRENT Quick Tunnel URL from KataBump (https://xxxxx.trycloudflare.com).
4. Leave Panel key empty unless WEB_API_KEY is configured in KataBump.
5. Press Save & Connect.
6. It will show Connected only after a real /api/health request succeeds.
7. Pairing uses GET /api/pair?phone=...

IMPORTANT:
- The Quick Tunnel URL changes when cloudflared creates a new tunnel. Always use the newest URL.
- Do not delete the WhatsApp session folder on KataBump.
- Do not delete node_modules unless you intentionally reinstall dependencies.
- This panel does not use the old Cloudflare Worker bridge.
